# A/B Test Analysis — Submission

## One-sentence task
Analyse a sample A/B experiment, compare conversion rates, and state whether the variant is better using a confidence interval and a statistical test.

## What is included
- `data/ab_test_sample.csv` — 2,000 synthetic user records (1,000 per group).
- `analyse_ab_test.py` — reusable analysis script, Wilson score intervals, Newcombe 95% CI for the difference, and a two-sided two-proportion z-test.
- `tests/` — normal-case and invalid-data tests.
- `report.md` — interpretation and conclusion.
- `outputs/` — generated results and conversion-rate chart.

## Dataset and experiment
The outcome is binary: `converted = 1` means the user converted; `0` means they did not. The sample has 1,000 users in each randomly assigned group. The data is synthetic and is intended for learning only.

## Run it
```bash
python -m pip install -r requirements.txt
python analyse_ab_test.py
python -m pytest -q
```
Run from this project directory. The script reads `data/ab_test_sample.csv` and writes `outputs/results.txt`.

## Method
1. Calculate each group's conversion rate.
2. Calculate absolute lift: Variant rate minus Control rate.
3. Calculate the relative lift compared with Control.
4. Calculate a 95% Newcombe hybrid-score confidence interval for the difference in proportions. This is based on Wilson score intervals.
5. Use a two-sided pooled two-proportion z-test with significance level 0.05.

## What I learned
A/B testing compares outcomes between a control experience and a changed variant. The confidence interval shows a plausible range for the true difference, while the p-value measures how surprising the observed difference would be if the true rates were equal. Statistical significance does not automatically imply practical or business significance.
