"""Analyse a two-sided A/B test for a binary conversion outcome."""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd
from scipy.stats import norm

def wilson_interval(successes: int, total: int, confidence: float = 0.95):
    """Wilson score confidence interval for one proportion."""
    if total <= 0:
        raise ValueError("total must be positive")
    if not 0 < confidence < 1:
        raise ValueError("confidence must be between 0 and 1")
    z = norm.ppf(1 - (1 - confidence) / 2)
    p = successes / total
    denom = 1 + z*z/total
    center = (p + z*z/(2*total)) / denom
    half = z * np.sqrt(p*(1-p)/total + z*z/(4*total*total)) / denom
    return center - half, center + half

def newcombe_difference_interval(x_control, n_control, x_variant, n_variant, confidence=0.95):
    """Newcombe hybrid-score CI for p_variant - p_control."""
    p_c, p_v = x_control/n_control, x_variant/n_variant
    lc, uc = wilson_interval(x_control, n_control, confidence)
    lv, uv = wilson_interval(x_variant, n_variant, confidence)
    diff = p_v - p_c
    lower = diff - np.sqrt((p_v-lv)**2 + (uc-p_c)**2)
    upper = diff + np.sqrt((uv-p_v)**2 + (p_c-lc)**2)
    return lower, upper

def analyse_ab_test(data: pd.DataFrame, confidence=0.95):
    required = {"group", "converted"}
    if not required.issubset(data.columns):
        raise ValueError(f"CSV must contain columns: {sorted(required)}")
    if not set(data["group"].dropna().unique()).issubset({"Control", "Variant"}):
        raise ValueError("group values must be Control or Variant")
    if data[["group", "converted"]].isna().any().any():
        raise ValueError("group and converted cannot contain missing values")
    if not set(data["converted"].unique()).issubset({0, 1}):
        raise ValueError("converted must contain only 0 or 1")

    c = data[data.group == "Control"]["converted"]
    v = data[data.group == "Variant"]["converted"]
    if len(c) == 0 or len(v) == 0:
        raise ValueError("Both Control and Variant groups must contain users")

    xc, nc = int(c.sum()), len(c)
    xv, nv = int(v.sum()), len(v)
    pc, pv = xc/nc, xv/nv
    diff = pv - pc
    pooled = (xc+xv)/(nc+nv)
    se_null = np.sqrt(pooled*(1-pooled)*(1/nc+1/nv))
    z = diff/se_null if se_null > 0 else 0.0
    p_value = 2*(1-norm.cdf(abs(z)))
    ci_low, ci_high = newcombe_difference_interval(xc, nc, xv, nv, confidence)
    rel_lift = diff/pc if pc else np.nan

    return {
        "control_users": nc, "control_conversions": xc, "control_rate": pc,
        "variant_users": nv, "variant_conversions": xv, "variant_rate": pv,
        "absolute_lift": diff, "relative_lift": rel_lift,
        "ci_low": ci_low, "ci_high": ci_high, "z_statistic": z,
        "p_value": p_value, "confidence": confidence,
    }

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="data/ab_test_sample.csv")
    parser.add_argument("--output", default="outputs/results.txt")
    args = parser.parse_args()
    data = pd.read_csv(args.input)
    result = analyse_ab_test(data)
    lines = [
        "A/B TEST ANALYSIS (synthetic sample data)",
        f"Control: {result['control_conversions']}/{result['control_users']} = {result['control_rate']:.1%}",
        f"Variant: {result['variant_conversions']}/{result['variant_users']} = {result['variant_rate']:.1%}",
        f"Absolute lift (Variant - Control): {result['absolute_lift']:.1%}",
        f"Relative lift: {result['relative_lift']:.1%}",
        f"95% CI for absolute lift: [{result['ci_low']:.1%}, {result['ci_high']:.1%}]",
        f"Two-sided z-test p-value: {result['p_value']:.4f}",
        "Conclusion: " + (
            "The variant has a statistically significant higher conversion rate at the 5% level."
            if result["p_value"] < 0.05 and result["ci_low"] > 0 else
            "The result is not statistically significant at the 5% level."
        ),
        "Caution: This is a simulated teaching dataset, not real customer evidence."
    ]
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(lines) + "\\n", encoding="utf-8")
    print("\n".join(lines))

if __name__ == "__main__":
    main()
