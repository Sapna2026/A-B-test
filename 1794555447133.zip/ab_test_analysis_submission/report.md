# A/B Test Analysis Report

## 1. Objective
Evaluate whether the Variant experience improves conversion compared with Control.

## 2. Data and metric
- Dataset: `data/ab_test_sample.csv`
- Sample size: 1,000 Control users and 1,000 Variant users.
- Primary metric: conversion rate = conversions / users.
- Outcome: binary (`1` = converted, `0` = did not convert).
- **Important:** This is a synthetic teaching dataset. It is not actual business or customer data.

## 3. Results

| Metric | Control | Variant |
|---|---:|---:|
| Users | 1,000 | 1,000 |
| Conversions | 120 | 150 |
| Conversion rate | 12.0% | 15.0% |

- Absolute lift (Variant − Control): **3.0%** (percentage points).
- Relative lift over Control: **25.0%**.
- 95% Newcombe confidence interval for absolute lift: **[0.0%, 6.0%]**.
- Two-sided two-proportion z-test: **z = 1.963, p = 0.04964**.
- Significance threshold: **0.05**.

## 4. Conclusion
The variant's conversion rate is statistically significantly higher than the control at the 5% level.

The estimated improvement is 3.0% (an increase of 3.0 percentage points). The 95% confidence interval is entirely above zero, which supports a positive effect for this sample. The p-value is below 0.05, so the equal-conversion-rate null hypothesis is rejected at the 5% level.

## 5. Recommendation and limitations
For this illustrative dataset, the Variant would be the preferred option. In a real experiment, confirm that users were randomly assigned, the test ran for a pre-planned duration, tracking worked consistently, and no major sample-ratio mismatch or novelty/seasonality effect occurred. Check guardrail metrics (e.g., revenue, refunds, latency, retention) before rollout. A statistically significant result may still be too small to matter commercially.

## 6. What I learned
An A/B test compares a control group with a variant group using a predefined metric. A confidence interval communicates uncertainty around the estimated difference; a p-value helps assess evidence against equal rates. Both should be interpreted alongside sample quality and practical impact.
