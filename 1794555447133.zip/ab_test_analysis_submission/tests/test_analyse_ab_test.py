import pandas as pd
import pytest
from analyse_ab_test import analyse_ab_test

def test_normal_case_detects_positive_lift():
    sample = pd.DataFrame({
        "group": ["Control"]*100 + ["Variant"]*100,
        "converted": [1]*10 + [0]*90 + [1]*20 + [0]*80
    })
    result = analyse_ab_test(sample)
    assert result["absolute_lift"] == pytest.approx(0.10)
    assert result["variant_rate"] > result["control_rate"]
    assert result["ci_low"] < result["ci_high"]

def test_failure_case_rejects_invalid_conversion_values():
    sample = pd.DataFrame({
        "group": ["Control", "Variant"],
        "converted": [0, 2]
    })
    with pytest.raises(ValueError, match="only 0 or 1"):
        analyse_ab_test(sample)

def test_failure_case_rejects_missing_experiment_group():
    sample = pd.DataFrame({"group": ["Control"], "converted": [1]})
    with pytest.raises(ValueError, match="Both Control and Variant"):
        analyse_ab_test(sample)
